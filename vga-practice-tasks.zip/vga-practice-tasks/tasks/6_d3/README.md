# Using D3.js

This task would guide you to use D3.js in your plugin. This would allow a more
flexible plugin implemetation.

Go to [`./chart.plugin.js`](./chart.plugin.js), find`TODO` labels, and follow
its instructions.
