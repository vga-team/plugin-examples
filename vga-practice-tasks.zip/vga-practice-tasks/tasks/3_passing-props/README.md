# Passing props from the configuration to the plugin

This task would guide you to receive props from the configuration file in your
plugin. This would allow a more flexible plugin implemetation.

Go to [`./my-better-tile-layer.plugin.js`](./my-better-tile-layer.plugin.js),
find `TODO` labels, and follow its instructions.
