# The first plugin

This task would guide you to create your first VGA plugin.

Go to [`./my-first.plugin.js`](./my-first.plugin.js), find `TODO` labels, and
follow its instructions.
