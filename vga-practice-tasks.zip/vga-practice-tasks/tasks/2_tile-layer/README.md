# The tile layer plugin

This task would guide you to create your first map layer (tile layer) plugin.

Go to [`./my-tile-layer.plugin.js`](./my-tile-layer.plugin.js), find `TODO`
labels, and follow its instructions.
