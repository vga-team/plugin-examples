# Large plugin view

This task would guide you to determine if the current plugin is in the large
plugin view and potentially make the plugin act differently. This would allow a
more flexible plugin implemetation.

Go to [`./foo.plugin.js`](./foo.plugin.js), find `TODO` labels, and follow its
instructions.
