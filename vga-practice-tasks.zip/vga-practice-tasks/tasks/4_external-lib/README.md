# Using a External Library

This task would guide you to use an external library in your plugin. This would
allow a more flexible plugin implemetation.

Go to [`./markdown.plugin.js`](./markdown.plugin.js),
find`TODO` labels, and follow its instructions.
