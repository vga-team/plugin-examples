# The GeoJSON layer plugin

This task would guide you to create a GeoJSON layer dashboard.

Go to [`./my-geojson-layer.plugin.js`](./my-geojson-layer.plugin.js), find
`TODO` labels, and follow its instructions.
