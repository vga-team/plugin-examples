# Local file access

This task would guide you to access local files. This would allow a more
flexible plugin implemetation.

This could usaful to implement a data provider plugin.

Go to [`./foo.plugin.js`](./foo.plugin.js), find `TODO` labels, and follow its
instructions.
