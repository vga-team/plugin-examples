# Sharing states between plugins

This task would guide you to share states between plugins. This would allow a
more flexible plugin implemetation.

First, go to [`./one.plugin.js`](./one.plugin.js) and check how we share
(update/consume) a state between plugin instances. Then, go to
[`./two.plugin.js`](./two.plugin.js), find `TODO` labels, and follow its
instructions.
